celsius = float(input("Ingrese la temperatura en °C: "))
fahrenheit = (celsius * 1.8) + 32
print("La temperatura en °F es:",fahrenheit )