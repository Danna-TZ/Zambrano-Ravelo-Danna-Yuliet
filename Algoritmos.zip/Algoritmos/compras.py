precioC = 35000
precioP = 75000
precioC = 900000

subtotalCA = precioC + precioP
descuentoCA = subtotalCA * 0.14
totalCA = subtotalCA - descuentoCA

totalD = totalCA + precioC

print("Subtotal Costa Azul: $",subtotalCA )
print("Descuento: $",descuentoCA)
print("Total Costa Azul: $", totalCA)
print("Total gastado en el día: $",totalD)