estatura = float(input("Ingrese la estatura en metros: "))
peso = float(input("Ingrese el peso en  kg: "))
imc = peso / (estatura ** 2)
print("Su IMC es: ",imc)