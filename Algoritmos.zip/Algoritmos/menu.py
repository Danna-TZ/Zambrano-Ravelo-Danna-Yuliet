print("1. IMC | 2. %GC | 3. TMB")
opcion = int(input("Seleccione una opción: "))
genero = input("Género (m/f): ")
edad = int(input("Edad en años: "))
peso = float(input("Peso en kg: "))
estatura = float(input("Estatura en metros: "))
imc = peso / (estatura ** 2)



if opcion == 1:
    print("IMC:",imc)
if opcion == 2:
    valgen = 10.8 if genero == "m" else 0.0
    gc = (1.2 * imc) + (0.23 * edad) - 5.4 - valgen
    print("Porcentaje de Grasa Corporal (%GC)%",gc)
if opcion == 3:
    altura_cm = float(input("Altura en cm: "))
    valgen = 5.0 if genero == "m" else -161.0
    tmb = (10 * peso) + (6.25 * altura_cm) - (5 * edad) + valgen
    print("Tasa Metabólica Basal (TMB):",tmb)